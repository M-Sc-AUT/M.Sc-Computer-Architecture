# Thesis Template

A LaTeX template for typesetting theses in Persian.

By: [Hamid Zarrabi-Zadeh](https://github.com/zarrabi)


## Changes
In this repository, I changed the fonts compared to the original version, Because <code>XB Niloofar</code> fonts were running on my system with errors. I replaced them with <code>Yas</code> font.

You can also check [this repository](https://github.com/rezaAdinepour/Bachelors-Thesis.git).
## Result
![image](2.png)

![image](1.png)

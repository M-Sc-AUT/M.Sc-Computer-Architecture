import numpy as np



a = np.array([-0.34, -0.12, 0.17, 0.74, 0.93])
b = np.array([0.46, 0.20, 0.81, -0.96, -0.11])

print(a + b)